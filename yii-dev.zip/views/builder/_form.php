<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
/* @var $this yii\web\View */
/* @var $model app\models\Builder */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="builder-form">

    <?php $form = ActiveForm::begin(); ?>
<div class='col-md-12'>
<div class='col-md-6'>
<div class='col-md-12'>    <?= $form->field($model, 'builder_name')->textInput(['maxlength' => true]) ?>

</div><div class='col-md-12'>    <?= $form->field($model, 'mobile')->textInput(['maxlength' => true]) ?>

</div><div class='col-md-12'>    <?= $form->field($model, 'alt_mobile')->textInput(['maxlength' => true]) ?>

</div><div class='col-md-12'>    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

</div><div class='col-md-12'>    <?= $form->field($model, 'address')->textarea(['rows' => 6]) ?>

</div></div><div class='col-md-6'><div class='col-md-12'><?= $form->field($model, 'state_id')->label('state_name')->dropDownList(
			yii\helpers\ArrayHelper::map(app\models\State::find()->orderBy('state_name')->asArray()->all(),'state_id','state_name'),array(
        'prompt' => '--Select a Type Name--' ))?></div><div class='col-md-12'><?= $form->field($model, 'city_id')->label('city_name')->dropDownList(
			yii\helpers\ArrayHelper::map(app\models\City::find()->orderBy('city_name')->asArray()->all(),'city_id','city_name'),array(
        'prompt' => '--Select a Type Name--' ))?></div><div class='col-md-12'>    <?= $form->field($model, 'created_at')->textInput() ?>

</div><div class='col-md-12'>    <?= $form->field($model, 'created_by')->textInput(['maxlength' => true]) ?>

</div></div></div>    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
